#this app cleans up the user input before comparing it to a list of definition and proposing the definition the english word to the user
#uses json for the dictionary list, difflib library to look for alternative spellings. Not very fast - can take a few seconds to iterate the list to propose alternate spellings.
import json

from difflib import get_close_matches

data=json.load(open("dictdata.json", "r"))

def translate(word):
    word = word.lower()

    if word in data:
        return data[word]
    
    elif word.title() in data:
        return data[word.title()]

    elif word.upper() in data:
        return data[word.upper()]

    elif len(get_close_matches(word, data.keys())) > 0:
        yn = input("Did you mean %s instead? Enter Y if yes, or N if no: " % get_close_matches(word, data.keys())[0])
        if yn == "Y" or yn == "y":
                return data[get_close_matches(word, data.keys())[0]]
        elif yn == "N" or yn == "n":
                return "The word is not available. Please check or try another word."
        else:
            return "Entry submitted not understood by the system."
    else:
        return "The word is not available. Please check or try another word."

word = input("Enter word: ")

output = translate(word)

if type(output) == list:
    for item in output:
        print(item)
else:
    print(output)